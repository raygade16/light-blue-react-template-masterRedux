# Changelog

## [1.2.7]

- Updated sidebar and navbar icons
- Updated sidebar and navbar design 

## [1.2.6]

- Fixed header's notification bar 
- Fixed charts legend labels

## [1.2.5]

- Fix layout issues
- Correct elements properties

## [1.2.4]

- Added link to flatlogic on login and register pages

## [1.2.3]

- Fix layout issues
- Change elements paddings and colors

## [1.2.2]

- Update dependencies, fixed security vulnerability

## [1.2.1]

- Update dependencies
- Add animation to alert in header
- Fix color in notifications
- Fix animated classes
- Fix color in chart dropdown menu

## [1.2.0]

Added Breadcrumbs component

## [1.1.1]

Fixed tables color

## [1.1.0]

Updated demo in the docs folder

## [1.0.0]

Initial release
